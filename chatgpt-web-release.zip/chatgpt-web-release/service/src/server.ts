import app from '.'

app.listen(3002, () => globalThis.console.log('Server is running on port 3002'))
